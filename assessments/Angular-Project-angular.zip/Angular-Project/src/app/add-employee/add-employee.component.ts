import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AppService } from '../app.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {

form: FormGroup;
submitted:boolean = false;
param :any;
constructor(private fb:FormBuilder, private service : AppService, private route: Router) { }

ngOnInit() {
  this.setForm();
  console.log(this.route.url)
  if(this.route.url != '/employees/new'){
    this.param = this.route.url.split("/")[2];
    console.log(this.param);
    this.form.patchValue(this.service.employee[this.param] );
    
  }
  else{
    
  }
}

setForm():void{
  this.form = this.fb.group({
    name: [null, Validators.required],
    age: [null,[Validators.required]],
    email: [null, Validators.required]
  });
}

hasError(controlName, validationName){
  return this.form.get(controlName).hasError(validationName) && (this.form.get(controlName).touched || this.submitted);
}

onSubmit():void{
  this.submitted = true;
  if(this.param){
    if(this.form.valid){
      this.service.employee[this.param]= this.form.value;
      this.form.reset();
      this.submitted = false;
      console.log(this.service.employee);
    }
  }else{

    if(this.form.valid){
      let size = this.service.employee.length;
      this.service.employee[size]= this.form.value;
      this.form.reset();
      this.submitted = false;
      console.log(this.service.employee);
    }
  }
}

}