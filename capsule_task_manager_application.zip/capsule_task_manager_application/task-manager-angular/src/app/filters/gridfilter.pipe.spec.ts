import { GridfilterPipe } from './gridfilter.pipe';

describe('GridfilterPipe', () => {
  it('create an instance', () => {
    const pipe = new GridfilterPipe();
    expect(pipe).toBeTruthy();
  });
});
